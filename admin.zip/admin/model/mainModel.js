const sqldb = require('../../config/dbconnect');
const dbutil = require(appRoot + '/utils/dbutils');
const moment = require('moment');
const fs = require('fs');
const path = require('path');


// Model to verify username and password
exports.loginMdl = function (dataarr, callback) {
    var cntxtDtls = "in loginMdl";


    var QRY_TO_EXEC = `SELECT * FROM public.admins 
    WHERE user_name = '${dataarr.user_name}' AND password = '${dataarr.password}';`;

    console.log(QRY_TO_EXEC);
    dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
        if (err) {
            console.error("Database query error:", err);
            return callback(err, null);
        }

        if (results.length > 0) {

            callback(null, results[0]);
        } else {

            callback(null, null);
        }
    });
};
// Customer management
exports.customerdetailsMdl = function (dataarr, callback) {
    var cntxtDtls = "in customerdetailsMdl";
    var QRY_TO_EXEC = `SELECT * FROM public.customers order by id asc;`; 

    if (callback && typeof callback === "function") {
        dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
            if (err) {
                console.error("Database query error:", err);
            }
            callback(err, results);
        });
    } else {
        return dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls);
    }
};
exports.customerByidMdl = function (dataarr, callback) {
    var cntxtDtls = "in customerByidMdl";
    var QRY_TO_EXEC = `SELECT * FROM public.customers WHERE id = ${dataarr.customer_id};`;
    console.log(QRY_TO_EXEC)
       // First query: Fetch customer details
     if (callback && typeof callback === "function") {
        dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
            if (err) {
                console.error("Database query error:", err);
            }
            callback(err, results);
        });
    } else {
        return dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls);
    }
};
// orders
exports.orderCustomerdetailsMdl = function (dataarr, callback) {
    var cntxtDtls = "in orderCustomerdetailsMdl";
    var QRY_TO_EXEC = `SELECT
  c.id,
  c.name,
  c.phone,
  c.address,
  cv.visit_status,
  cv.reschedule_date,
  cv.visit_date
FROM public.customers c
LEFT JOIN (
  SELECT DISTINCT ON (customer_id) *
  FROM public.customer_visits
  ORDER BY customer_id, visit_date DESC
) cv ON cv.customer_id = c.id;`; 

    if (callback && typeof callback === "function") {
        dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
            if (err) {
                console.error("Database query error:", err);
            }
            callback(err, results);
        });
    } else {
        return dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls);
    }
};

exports.scheduleBulkMdl = function (dataarr, callback) {
     const cntxtDtls = 'in scheduleBulkMdl';
    const customer_ids = dataarr.customer_ids;

    if (!Array.isArray(customer_ids) || customer_ids.length === 0) {
        return callback(new Error('Invalid customer_ids array'), null);
    }

    const event_date = moment().utcOffset('+05:30').format('YYYY-MM-DD');
    let QRY_TO_EXEC = '';

    for (let i = 0; i < customer_ids.length; i++) {
        const id = customer_ids[i];
        QRY_TO_EXEC += `
            INSERT INTO customer_visits (customer_id, visit_status, visit_date)
            VALUES (${id}, 'scheduled', '${event_date}');
        `;
    }

    console.log(QRY_TO_EXEC);

    if (callback && typeof callback === 'function') {
        dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
            if (err) {
                console.error('Database query error:', err);
            }
            callback(err, results);
        });
    } else {
        return dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls);
    }
};

// exports.assignRunnerMdl = function (dataarr, callback) {
//     var cntxtDtls = "in assignRunnerMdl";
//     console.log(dataarr.company_id);
//     var QRY_TO_EXEC = `update customer_visits SET runner_id = ${dataarr.runner_id} WHERE id IN (${dataarr.ids});`;
//     console.log(QRY_TO_EXEC);

//     if (callback && typeof callback === "function") {
//         dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
//             if (err) {
//                 console.error("Database query error:", err);
//             }
//             callback(err, results);
//         });
//     } else {
//         return dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls);
//     }
// };

exports.assignRunnerMdl = function (dataarr, callback) {
    const cntxtDtls = "in assignRunnerMdl";

    if (!Array.isArray(dataarr.ids) || dataarr.ids.length === 0) {
        return callback(new Error("Invalid ids array"), null);
    }

    const idList = dataarr.ids.map(id => parseInt(id)).filter(Boolean).join(','); // sanitize
    const runnerId = parseInt(dataarr.runner_id);

    if (!runnerId || !idList) {
        return callback(new Error("Invalid runner_id or empty id list"), null);
    }

    const QRY_TO_EXEC = `
        UPDATE customer_visits
        SET runner_id = ${runnerId}
        WHERE id IN (${idList});
    `;

    dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
        if (err) {
            console.error("Database query error:", err);
        }
        callback(err, results);
    });
};

exports.postWeightCategoriesMdl = function (data, callback) {
    const cntxtDtls = "in postWeightCategoriesMdl";

    
    const weight = parseFloat(data.weight_in_grams);
    

    if ( isNaN(weight)) {
        return callback(new Error("Invalid input data"), null);
    }

    const QRY_TO_EXEC = ` INSERT INTO public.weight_categories (unit, weight_in_grams, status)
        VALUES ('grams', ${weight}, 0); `;

    dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
        if (err) {
            console.error("Database query error:", err);
        }
        callback(err, results);
    });
};

exports.getWeightCategoriesMdl = function (callback) {
    const cntxtDtls = "in getWeightCategoriesMdl";

    const QRY_TO_EXEC = `
        SELECT id, unit, weight_in_grams, status
        FROM public.weight_categories where status=0
        ORDER BY weight_in_grams ASC;
    `;

    dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
        if (err) {
            console.error("Database query error:", err);
        }
        callback(err, results);
    });
};
exports.deleteWeightCategoriesMdl = function (data, callback) {
    const cntxtDtls = "in deleteWeightCategoriesMdl";
    const id = parseInt(data.id);

    if (!id) {
        return callback(new Error("Invalid or missing id"), null);
    }

    const QRY_TO_EXEC = `
        UPDATE public.weight_categories
        SET status = 1
        WHERE id = ${id};
    `;

    dbutil.execQuery(sqldb.PgConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
        if (err) {
            console.error("Database query error:", err);
        }
        callback(err, results);
    });
};




