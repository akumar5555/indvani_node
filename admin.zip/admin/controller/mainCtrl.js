require('dotenv').config();

const http = require("https");
const fs = require('fs');


const appmdl = require('../model/mainModel');
const { body, validationResult } = require('express-validator');
const express = require('express');



// Login Controller
exports.loginCtrl = function (req, res) {
    var dataarr = req.body;

    // Call the model to verify username and password
    appmdl.loginMdl(dataarr, function (err, user) {
        if (err) {
            console.error("Error in loginMdl:", err);
            return res.status(500).send({ status: 500, msg: "Server Error" });
        }

        if (user) {
            // Login successful, return user details
            res.status(200).send({
                status: 200,
                msg: "Login successful",
                data: user
            });
        } else {
            // No user found or password doesn't match
            res.status(400).send({ status: 401, msg: "Invalid username or password" });
        }
    });
};
// Customer management
exports.customerdetailsCtrl = function (req, res) {
    console.log("Received GET request with body:", req.body);

    // You may need to process data from req.body if needed
    var dataarr = req.body;

    appmdl.customerdetailsMdl(dataarr, function (err, results) {
        if (err) {
            console.error("Error in customerdetailsMdl:", err);
            res.status(500).send({ "status": 500, "msg": "Server Error" });
            return;
        }

        console.log("Query results:", results);
        if (results.length > 0) {
            res.status(200).send({ 'status': 200, "msg": "Customer Details Retrieves Successfully...", 'data': results });
        } else {
            res.status(300).send({ 'status': 300, 'data': [] });
        }
    });
}

exports.customerByidCtrl = function (req, res) {
    console.log("Received POST request with body:", req.body);

    var dataarr = req.query;

    // Call the model to get customer and proposal details
    appmdl.customerByidMdl(dataarr, function (err, results) {
        if (err) {
            console.error("Error in customerByidMdl:", err);
            return res.status(500).send({ "status": 500, "msg": "Server Error" });
        }

         if (results.length > 0) {
            res.status(200).send({ 'status': 200, "msg": "Customer Details Retrieves Successfully...", 'data': results });
        } else {
            res.status(300).send({ 'status': 300, 'data': [] });
        }
    });
};

// orders

exports.orderCustomerdetailsCtrl = function (req, res) {
    console.log("Received GET request with body:", req.body);

    // You may need to process data from req.body if needed
    var dataarr = req.body;

    appmdl.orderCustomerdetailsMdl(dataarr, function (err, results) {
        if (err) {
            console.error("Error in orderCustomerdetailsMdl:", err);
            res.status(500).send({ "status": 500, "msg": "Server Error" });
            return;
        }

        console.log("Query results:", results);
        if (results.length > 0) {
            res.status(200).send({ 'status': 200, "msg": "Customer Details Retrieves Successfully...", 'data': results });
        } else {
            res.status(300).send({ 'status': 300, 'data': [] });
        }
    });
}

exports.scheduleBulkCtrl = function (req, res) {
    dataarr = req.body
 const customer_ids = dataarr.customer_ids;

if (!Array.isArray(dataarr.customer_ids) || dataarr.customer_ids.length === 0) {
return res.status(400).json({ error: 'customer_ids must be a non-empty array' });
}

appmdl.scheduleBulkMdl(dataarr, function (err, result) {
if (err) {
console.error('Error scheduling customers:', err);
return res.status(500).json({ error: 'Failed to schedule customer events' });
}
res.status(200).json({
  message: 'Customers scheduled successfully',
  inserted_count: customer_ids.length,
})
})
}

exports.assignRunnerCtrl = function (req, res) {
    const dataarr = req.body;

    if (!Array.isArray(dataarr.ids) || !dataarr.runner_id) {
        return res.status(400).send({ status: 400, msg: "Missing runner_id or ids array" });
    }

    appmdl.assignRunnerMdl(dataarr, function (err, results) {
        if (err) {
            console.error("Error in Assign Runner", err);
            return res.status(500).send({ status: 500, msg: "Server Error" });
        }

        return res.status(200).json({ message: 'Runner updated for selected visits' });
    });
};

exports.postWeightCategoriesCtrl = function (req, res) {
    const data = req.body;

    if ( !data.weight_in_grams) {
        return res.status(400).send({ status: 400, msg: "Missing required field: weight_in_grams" });
    }

    appmdl.postWeightCategoriesMdl(data, function (err, results) {
        if (err) {
            console.error("Error in Insert Weight Category", err);
            return res.status(500).send({ status: 500, msg: "Server Error" });
        }

        return res.status(200).json({ message: 'Weight category inserted successfully' });
    });
};

exports.getWeightCategoriesCtrl = function (req, res) {
    appmdl.getWeightCategoriesMdl(function (err, results) {
        if (err) {
            console.error("Error fetching weight categories:", err);
            return res.status(500).send({ status: 500, msg: "Server Error" });
        }

        return res.status(200).json({
            status: 200,
            msg: "Weight categories fetched successfully",
            data: results
        });
    });
};

exports.deleteWeightCategoriesCtrl = function (req, res) {
    const data = req.body;

    if (!data.id) {
        return res.status(400).send({ status: 400, msg: "Missing weight category id" });
    }

    appmdl.deleteWeightCategoriesMdl(data, function (err, results) {
        if (err) {
            console.error("Error deleting weight category:", err);
            return res.status(500).send({ status: 500, msg: "Server Error" });
        }

        return res.status(200).json({ message: 'Weight category deleted Successfully...' });
    });
};



