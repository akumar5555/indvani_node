var express = require('express');
var router = express.Router();
var sampleRoutes = require('../controller/mainCtrl'); // Ensure path is correct

// Define routes
// router.post('/postCompanydetails', sampleRoutes.postCompanyCtrl); // Route for company registration
// router.get('/getCompanydetails', sampleRoutes.getCompanydetailsCtrl); // Route for fetching customer details

router.post('/login', sampleRoutes.loginCtrl); 
router.get('/customerDtls', sampleRoutes.customerdetailsCtrl); 
 router.get('/customerByid', sampleRoutes.customerByidCtrl); 
router.post('/scheduleBulk', sampleRoutes.scheduleBulkCtrl); 

router.get('/orderCustomerdetails', sampleRoutes.orderCustomerdetailsCtrl); 
router.post('/assignRunner', sampleRoutes.assignRunnerCtrl)
router.post('/postWeightCategories', sampleRoutes.postWeightCategoriesCtrl)
router.get('/getWeightCategories', sampleRoutes.getWeightCategoriesCtrl);

router.post('/deleteWeightCategories', sampleRoutes.deleteWeightCategoriesCtrl);



module.exports = router;
